package com.mascotitas.exception;

public class AsistenteNoDisponibleException extends Exception {
    public AsistenteNoDisponibleException(String mensaje) {
        super(mensaje);
    }
}
