package com.mascotitas.exception;

public class VeterinarioNoDisponibleException extends Exception {
    public VeterinarioNoDisponibleException(String mensaje) {
        super(mensaje);
    }
}
